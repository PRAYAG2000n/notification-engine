import http from "k6/http";
import { check, sleep } from "k6";
import { Counter, Rate, Trend } from "k6/metrics";

// Custom metrics
const eventsPublished = new Counter("events_published");
const eventLatency = new Trend("event_publish_latency_ms");
const eventErrors = new Rate("event_publish_errors");

export const options = {
  scenarios: {
    // Scenario: sustained event publishing to hit 10,450+ events/min
    event_burst: {
      executor: "constant-arrival-rate",
      rate: 175,            // 175 requests/second = 10,500/min
      timeUnit: "1s",
      duration: "2m",       // Run for 2 minutes
      preAllocatedVUs: 50,
      maxVUs: 200,
    },
  },
  thresholds: {
    events_published: ["count>20000"],           // At least 20k events in 2 min
    event_publish_latency_ms: ["p(95)<200"],     // 95% under 200ms
    event_publish_errors: ["rate<0.05"],          // Less than 5% error rate
    http_req_duration: ["p(95)<300"],
  },
};

const BASE_URL = __ENV.BASE_URL || "http://localhost:3000";

// Pre-generated notification payloads
const notificationTypes = ["SYSTEM", "ALERT", "MESSAGE", "TASK", "REMINDER", "UPDATE"];
const priorities = ["LOW", "NORMAL", "HIGH", "URGENT"];

export default function () {
  const type = notificationTypes[Math.floor(Math.random() * notificationTypes.length)];
  const priority = priorities[Math.floor(Math.random() * priorities.length)];
  const timestamp = new Date().toISOString();

  const payload = JSON.stringify({
    type: type,
    priority: priority,
    title: `Load test event ${__VU}-${__ITER}`,
    body: `Automated event generated at ${timestamp} by VU ${__VU}`,
    metadata: {
      source: "k6-load-test",
      vu: __VU,
      iteration: __ITER,
      timestamp: timestamp,
    },
  });

  const params = {
    headers: {
      "Content-Type": "application/json",
    },
    tags: { name: "publish_event" },
  };

  const startTime = Date.now();
  const res = http.post(`${BASE_URL}/api/events/publish`, payload, params);
  const latency = Date.now() - startTime;

  eventLatency.add(latency);

  const success = check(res, {
    "status is 200 or 201": (r) => r.status === 200 || r.status === 201,
    "response has id": (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.id !== undefined || body.eventId !== undefined;
      } catch {
        return false;
      }
    },
  });

  if (success) {
    eventsPublished.add(1);
    eventErrors.add(0);
  } else {
    eventErrors.add(1);
  }
}

export function handleSummary(data) {
  const totalEvents = data.metrics.events_published
    ? data.metrics.events_published.values.count
    : 0;
  const durationSec = data.state.testRunDurationMs / 1000;
  const eventsPerMin = ((totalEvents / durationSec) * 60).toFixed(0);

  const summary = {
    totalEventsPublished: totalEvents,
    testDurationSeconds: durationSec.toFixed(1),
    eventsPerMinute: parseInt(eventsPerMin),
    publishLatency: {
      avg: data.metrics.event_publish_latency_ms
        ? data.metrics.event_publish_latency_ms.values.avg.toFixed(2)
        : "N/A",
      p95: data.metrics.event_publish_latency_ms
        ? data.metrics.event_publish_latency_ms.values["p(95)"].toFixed(2)
        : "N/A",
      p99: data.metrics.event_publish_latency_ms
        ? data.metrics.event_publish_latency_ms.values["p(99)"].toFixed(2)
        : "N/A",
    },
    errorRate: data.metrics.event_publish_errors
      ? (data.metrics.event_publish_errors.values.rate * 100).toFixed(2) + "%"
      : "0%",
    httpReqDuration: {
      avg: data.metrics.http_req_duration
        ? data.metrics.http_req_duration.values.avg.toFixed(2)
        : "N/A",
      p95: data.metrics.http_req_duration
        ? data.metrics.http_req_duration.values["p(95)"].toFixed(2)
        : "N/A",
    },
  };

  console.log("\n========== EVENT THROUGHPUT RESULTS ==========");
  console.log(`Total Events Published: ${summary.totalEventsPublished}`);
  console.log(`Test Duration: ${summary.testDurationSeconds}s`);
  console.log(`Events Per Minute: ${summary.eventsPerMinute}`);
  console.log(
    `Publish Latency (avg/p95/p99): ${summary.publishLatency.avg}ms / ${summary.publishLatency.p95}ms / ${summary.publishLatency.p99}ms`
  );
  console.log(`Error Rate: ${summary.errorRate}`);
  console.log(
    `HTTP Duration (avg/p95): ${summary.httpReqDuration.avg}ms / ${summary.httpReqDuration.p95}ms`
  );
  console.log("================================================\n");

  return {
    "event-throughput-results.json": JSON.stringify(summary, null, 2),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}

import { textSummary } from "https://jslib.k6.io/k6-summary/0.0.2/index.js";
