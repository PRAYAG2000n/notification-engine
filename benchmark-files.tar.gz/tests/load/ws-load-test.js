import ws from "k6/ws";
import { check, sleep } from "k6";
import { Counter, Trend } from "k6/metrics";

// Custom metrics
const messagesReceived = new Counter("ws_messages_received");
const messageLatency = new Trend("ws_message_latency_ms");
const connectionTime = new Trend("ws_connection_time_ms");

export const options = {
  stages: [
    { duration: "30s", target: 50 },   // Ramp to 50 users
    { duration: "30s", target: 100 },  // Ramp to 100 users
    { duration: "30s", target: 200 },  // Ramp to 200 users
    { duration: "60s", target: 200 },  // Hold at 200 for 1 minute
    { duration: "30s", target: 0 },    // Ramp down
  ],
  thresholds: {
    ws_connection_time_ms: ["p(95)<500"],       // 95% connect under 500ms
    ws_message_latency_ms: ["p(95)<100"],       // 95% message latency under 100ms
    ws_messages_received: ["count>0"],
    checks: ["rate>0.95"],                       // 95% success rate
  },
};

const WS_URL = __ENV.WS_URL || "ws://localhost:3001";

export default function () {
  const userId = `loadtest-user-${__VU}`;
  const connectStart = Date.now();

  const res = ws.connect(
    WS_URL,
    {
      headers: { "X-User-Id": userId },
    },
    function (socket) {
      const connectEnd = Date.now();
      connectionTime.add(connectEnd - connectStart);

      socket.on("open", () => {
        // Send auth handshake
        socket.send(
          JSON.stringify({
            type: "auth",
            userId: userId,
          })
        );
      });

      socket.on("message", (data) => {
        const msg = JSON.parse(data);
        messagesReceived.add(1);

        // Measure latency if timestamp is present
        if (msg.timestamp) {
          const latency = Date.now() - new Date(msg.timestamp).getTime();
          messageLatency.add(latency);
        }

        check(msg, {
          "message has type": (m) => m.type !== undefined || m.event !== undefined,
        });
      });

      socket.on("error", (e) => {
        console.error(`WebSocket error for ${userId}: ${e.error()}`);
      });

      // Keep connection alive for the duration
      socket.setTimeout(function () {
        socket.close();
      }, 150000); // 2.5 minutes

      // Simulate periodic activity
      for (let i = 0; i < 10; i++) {
        socket.setTimeout(function () {
          socket.send(
            JSON.stringify({
              type: "ping",
              timestamp: new Date().toISOString(),
            })
          );
        }, i * 5000);
      }
    }
  );

  check(res, {
    "WebSocket connected successfully": (r) => r && r.status === 101,
  });

  sleep(1);
}

export function handleSummary(data) {
  const summary = {
    totalVUs: data.metrics.vus_max ? data.metrics.vus_max.values.max : 0,
    connectionTime: {
      avg: data.metrics.ws_connection_time_ms
        ? data.metrics.ws_connection_time_ms.values.avg.toFixed(2)
        : "N/A",
      p95: data.metrics.ws_connection_time_ms
        ? data.metrics.ws_connection_time_ms.values["p(95)"].toFixed(2)
        : "N/A",
    },
    messageLatency: {
      avg: data.metrics.ws_message_latency_ms
        ? data.metrics.ws_message_latency_ms.values.avg.toFixed(2)
        : "N/A",
      p95: data.metrics.ws_message_latency_ms
        ? data.metrics.ws_message_latency_ms.values["p(95)"].toFixed(2)
        : "N/A",
    },
    messagesReceived: data.metrics.ws_messages_received
      ? data.metrics.ws_messages_received.values.count
      : 0,
    checksPassRate: data.metrics.checks
      ? (data.metrics.checks.values.rate * 100).toFixed(2) + "%"
      : "N/A",
  };

  console.log("\n========== LOAD TEST RESULTS ==========");
  console.log(`Peak Concurrent Users: ${summary.totalVUs}`);
  console.log(
    `Connection Time (avg/p95): ${summary.connectionTime.avg}ms / ${summary.connectionTime.p95}ms`
  );
  console.log(
    `Message Latency (avg/p95): ${summary.messageLatency.avg}ms / ${summary.messageLatency.p95}ms`
  );
  console.log(`Messages Received: ${summary.messagesReceived}`);
  console.log(`Check Pass Rate: ${summary.checksPassRate}`);
  console.log("========================================\n");

  return {
    "load-test-results.json": JSON.stringify(summary, null, 2),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}

import { textSummary } from "https://jslib.k6.io/k6-summary/0.0.2/index.js";
