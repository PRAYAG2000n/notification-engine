#!/bin/bash
set -e

echo "=========================================="
echo "  NotifyHub - Full Benchmark Suite"
echo "=========================================="

RESULTS_DIR="./benchmark-results"
mkdir -p "$RESULTS_DIR"

# ─── 1. Bundle Size Analysis ──────────────────────────────────
echo ""
echo "[1/4] Analyzing bundle size..."

# Build the app and capture output
npm run build 2>&1 | tee "$RESULTS_DIR/build-output.txt"

# Check .next directory for bundle sizes
echo ""
echo "--- Bundle Analysis ---"

# Get total client-side JS size
if [ -d ".next/static/chunks" ]; then
  TOTAL_RAW=$(find .next/static/chunks -name "*.js" | xargs du -cb 2>/dev/null | tail -1 | cut -f1)
  TOTAL_GZIP=0

  for f in .next/static/chunks/*.js; do
    if [ -f "$f" ]; then
      GZ_SIZE=$(gzip -c "$f" | wc -c)
      TOTAL_GZIP=$((TOTAL_GZIP + GZ_SIZE))
    fi
  done

  TOTAL_RAW_KB=$((TOTAL_RAW / 1024))
  TOTAL_GZIP_KB=$((TOTAL_GZIP / 1024))

  echo "Total client JS (raw): ${TOTAL_RAW_KB}KB"
  echo "Total client JS (gzipped): ${TOTAL_GZIP_KB}KB"

  # Check first-load JS for main pages
  echo ""
  echo "Page-level first-load JS (from build output):"
  grep -E "^[├└│ ]*[/○◐●λ]" "$RESULTS_DIR/build-output.txt" 2>/dev/null || echo "See build-output.txt for details"

  # Save results
  echo "{\"totalRawKB\": $TOTAL_RAW_KB, \"totalGzipKB\": $TOTAL_GZIP_KB}" > "$RESULTS_DIR/bundle-size.json"
else
  echo "Build output not found. Run 'npm run build' first."
fi

# ─── 2. Lighthouse Audit ─────────────────────────────────────
echo ""
echo "[2/4] Running Lighthouse audit..."

# Check if lhci is installed
if ! command -v lhci &> /dev/null; then
  echo "Installing Lighthouse CI..."
  npm install -g @lhci/cli
fi

# Start the production server in background
PORT=3000 npm start &
SERVER_PID=$!
sleep 5

# Run Lighthouse
if command -v lhci &> /dev/null; then
  lhci autorun --config=lighthouserc.js 2>&1 | tee "$RESULTS_DIR/lighthouse-output.txt"

  # Copy results
  if [ -d "./lighthouse-results" ]; then
    cp -r ./lighthouse-results/* "$RESULTS_DIR/" 2>/dev/null || true
  fi
else
  # Fallback: run lighthouse directly
  if command -v lighthouse &> /dev/null; then
    lighthouse http://localhost:3000/login \
      --output=json,html \
      --output-path="$RESULTS_DIR/lighthouse-login" \
      --chrome-flags="--headless --no-sandbox" \
      --throttling.rttMs=150 \
      --throttling.throughputKbps=1638.4 \
      --quiet

    lighthouse http://localhost:3000/dashboard \
      --output=json,html \
      --output-path="$RESULTS_DIR/lighthouse-dashboard" \
      --chrome-flags="--headless --no-sandbox" \
      --throttling.rttMs=150 \
      --throttling.throughputKbps=1638.4 \
      --quiet
  else
    echo "Neither lhci nor lighthouse found."
    echo "Install with: npm install -g @lhci/cli lighthouse"
    echo "Skipping Lighthouse audit."
  fi
fi

# Stop the production server
kill $SERVER_PID 2>/dev/null || true

# ─── 3. k6 WebSocket Load Test (200 users) ───────────────────
echo ""
echo "[3/4] Running WebSocket load test (200 concurrent users)..."

if ! command -v k6 &> /dev/null; then
  echo "k6 not found. Installing..."
  sudo gpg -k
  sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D68
  echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" | sudo tee /etc/apt/sources.list.d/k6.list
  sudo apt-get update
  sudo apt-get install k6 -y
fi

# Start dev server for load testing
npm run dev &
DEV_PID=$!
sleep 8

if command -v k6 &> /dev/null; then
  k6 run tests/load/ws-load-test.js \
    --out json="$RESULTS_DIR/ws-load-results.json" \
    2>&1 | tee "$RESULTS_DIR/ws-load-output.txt"
else
  echo "k6 still not available. Skipping WebSocket load test."
fi

# ─── 4. k6 Event Throughput Test (10,450+ events/min) ────────
echo ""
echo "[4/4] Running event throughput test (target: 10,450 events/min)..."

if command -v k6 &> /dev/null; then
  k6 run tests/load/event-throughput-test.js \
    --out json="$RESULTS_DIR/event-throughput-results.json" \
    2>&1 | tee "$RESULTS_DIR/event-throughput-output.txt"
else
  echo "k6 not available. Skipping event throughput test."
fi

# Stop dev server
kill $DEV_PID 2>/dev/null || true

# ─── Summary ─────────────────────────────────────────────────
echo ""
echo "=========================================="
echo "  Benchmark Suite Complete"
echo "=========================================="
echo ""
echo "Results saved to: $RESULTS_DIR/"
echo ""
ls -la "$RESULTS_DIR/"
echo ""
echo "Key files:"
echo "  bundle-size.json          - Client JS bundle sizes"
echo "  build-output.txt          - Next.js build output"
echo "  lighthouse-output.txt     - Lighthouse scores"
echo "  ws-load-output.txt        - WebSocket 200-user test"
echo "  event-throughput-output.txt - Event throughput test"
echo "=========================================="
